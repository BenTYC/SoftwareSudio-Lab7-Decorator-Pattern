package netdb.courses.softwarestudio.lab.main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import netdb.courses.softwarestudio.lab.io.LowerCaseReader;

public class App {
	public static void main(String[] args) throws IOException {

		// Enter file names
		BufferedReader keyReader = new BufferedReader(new InputStreamReader(
				System.in));
		String inputFile, outputFile;
		System.out.println("Please enter input file name:");
		inputFile = keyReader.readLine();
		System.out.println("Please enter output file name:");
		outputFile = keyReader.readLine();

		BufferedReader br;
		BufferedWriter bw;

		// TODO initialize the reader and writer here
		// remember to include your LowerCaseReader
		br = new BufferedReader(new LowerCaseReader(new FileReader(inputFile)));
		bw = new BufferedWriter(new FileWriter(outputFile));

		// TODO use a while loop to read the string from the input file
		// and then write to the output file
		int n;
		char[] cbuf = new char[10];
		while (-1 != (n = br.read(cbuf, 0, 10))) {
			bw.write(cbuf, 0, n);;
		}

		// TODO remember to flush your writer
		// using flush() method
		bw.flush();

		// TODO close the reader and writer;
		br.close();
		bw.close();

	}
}
